// Gali Cricket Website JavaScript

document.addEventListener("DOMContentLoaded", function () {
  console.log("✅ Gali Cricket website loaded successfully!");

  // Future dynamic updates can be added here
});